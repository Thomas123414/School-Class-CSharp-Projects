﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Folio_1_Textboxes_labels__list_boxes__buttons
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btDisplayClick_Click(object sender, EventArgs e)
        {
            lstDetails.Items.Add("FirstName: " + txtFirstname.Text);
            lstDetails.Items.Add('');
            lstDetails.Items.Add("Surname: " + txtSurname.Text);
            lstDetails.Items.Add('');
            lstDetails.Items.Add("Year_Level: " + txtYearLevel.Text);
            lstDetails.Items.Add('');
            lstDetails.Items.Add("House: " + txtHouse.Text);
            lstDetails.Items.Add('');
            lstDetails.Items.Add("Event_1: " + txtEvent1.Text);
            lstDetails.Items.Add('');
            lstDetails.Items.Add("Event_2: " + txtEvent2.Text);
        }

        private void btDisplayDelete_Click(object sender, EventArgs e)
        {
            lstDetails.Items.Clear();
            txtFirstname.Clear();
            txtSurname.Clear();
            txtYearLevel.Clear();
            txtHouse.Clear();
            txtEvent1.Clear();
            txtEvent2.Clear();
        }

        private void txtFirstname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
