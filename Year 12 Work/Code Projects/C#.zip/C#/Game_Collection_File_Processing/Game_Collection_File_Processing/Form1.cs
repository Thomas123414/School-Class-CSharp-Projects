using System.Xml.Linq;
using System.IO;
namespace Game_Collection_File_Processing
{
    /*Program function: Reads and writes records to a file
     * Programmer: Mr W
     * Date: 16/2
     * */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static int selected_ID = 0;            //This variable stores the index of the record array to be edited - it will be unsed in the second form

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ID;                 //Assign Input variables
            int newID;                 //New ID for appended file
            string path = "gamelist.txt";
            string title = txtTitle.Text;
            string genre = txtGenre.Text;
            string value = txtValue.Text;

            if (File.Exists(path))          //if the file exists
            {
                string[] lines = File.ReadAllLines(path);    //Store the file in array lines
                string[] items = lines[lines.Length - 1].Split(',');  //Put the last record into the array and use Split function to seperate fields
                newID = int.Parse(items[0]) + 1;                     //Add 1 to the ID of the last record on file
                ID = newID.ToString();                                 //assign the newID value to the ID field 

            }
            else
            {
                ID = "1";                                               //if this is the first record on file assign the value 1 to ID
            }

            string record = ID + "," + title + "," + genre + "," + value;   //Store all fields in 1 line sepparated by commas




            using (TextWriter tw = new StreamWriter(path, true))    //Use StreamWriter function to store/append record to file - will create file if it doesnt exist
            {
                tw.WriteLine(record);
                MessageBox.Show("Record successfully added!");
                tw.Close();     //Close file
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            int total_value = 0;
            string path = "gamelist.txt";
            string[] lines = File.ReadAllLines(path);  //Open file and store each line of the textfile into the array lines


            lsvOutput.Items.Clear();                  //Clear listview table
            foreach (string line in lines)              //Go through the file array 1 line at a time
            {

                string[] items = line.Split(",");  //Put each field in the line into an array (items) using split function 
                total_value += int.Parse(items[3]);
                ListViewItem listItem = new ListViewItem();   //"Row" object.

                //For each item in the line. Display each record field in the Listview table row
                for (int i = 0; i < items.Length; i++)
                {
                    if (i == 0)
                    {
                        listItem.Text = items[i]; //First item is not a "subitem".
                    }
                    else
                    {
                        listItem.SubItems.Add(items[i]); //Add it to the "Row" object.
                    }
                }

                lsvOutput.Items.Add(listItem); //Add the row object to the listview.

            }
            //MessageBox.Show("Total value of Game collection: $" + total_value);

        }

        private void lsvOutput_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (lsvOutput.SelectedItems.Count==0)       //if listview row is not selected
            {
                MessageBox.Show("Please select a record to edit!");
            }
            else
            {
                selected_ID = lsvOutput.SelectedIndices[0];      //store the index of the selected listview object
                Edit f2 = new Edit();                            //Create an instance of the Edit form
                f2.ShowDialog();                                 //Open the form
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string genre = textBox1.Text;              //Field to be searched for using a linear search
            int total_value = 0;                        //total_value field to tally all of the prices of each game stored on file
            string path = "gamelist.txt";
            string[] lines = File.ReadAllLines(path);  //Open file and store each line of the textfile into the array lines


            lsvOutput.Items.Clear();                  //Clear listview table
            foreach (string line in lines)              //Go through the file array 1 line at a time
            {

                string[] items = line.Split(",");  //Put each field in the line into an array (items) using split function 
                total_value += int.Parse(items[3]);

                if (genre == items[2])               //Filter the output to only include genre enterd in the text box
                {
                    ListViewItem listItem = new ListViewItem();   //"Row" object.

                    //For each item in the line. Display each record field in the Listview table row
                    for (int i = 0; i < items.Length; i++)
                    {
                        if (i == 0)
                        {
                            listItem.Text = items[i]; //First item is not a "subitem".
                        }
                        else
                        {
                            listItem.SubItems.Add(items[i]); //Add it to the "Row" object.
                        }
                    }

                    lsvOutput.Items.Add(listItem); //Add the row object to the listview.
                }
                else
                    MessageBox.Show("Not found");        //If the searched value is not on file display message

            }
            MessageBox.Show("Total value of Game collection: $" + total_value);
        }
    }
}