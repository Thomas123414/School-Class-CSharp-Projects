﻿namespace Game_Collection_File_Processing
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtTitle = new TextBox();
            txtGenre = new TextBox();
            txtValue = new TextBox();
            button2 = new Button();
            ID = new ColumnHeader();
            Title = new ColumnHeader();
            Genre = new ColumnHeader();
            Value = new ColumnHeader();
            lsvOutput = new ListView();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(150, 344);
            button1.Name = "button1";
            button1.Size = new Size(130, 37);
            button1.TabIndex = 0;
            button1.Text = "Save to file";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(350, 19);
            label1.Name = "label1";
            label1.Size = new Size(295, 32);
            label1.TabIndex = 1;
            label1.Text = "Game Collection Database";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(144, 136);
            label3.Name = "label3";
            label3.Size = new Size(32, 15);
            label3.TabIndex = 3;
            label3.Text = "Title:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(144, 166);
            label4.Name = "label4";
            label4.Size = new Size(41, 15);
            label4.TabIndex = 4;
            label4.Text = "Genre:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(144, 198);
            label5.Name = "label5";
            label5.Size = new Size(68, 15);
            label5.TabIndex = 5;
            label5.Text = "Value(new):";
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(228, 128);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(100, 23);
            txtTitle.TabIndex = 7;
            // 
            // txtGenre
            // 
            txtGenre.Location = new Point(229, 163);
            txtGenre.Name = "txtGenre";
            txtGenre.Size = new Size(100, 23);
            txtGenre.TabIndex = 8;
            // 
            // txtValue
            // 
            txtValue.Location = new Point(228, 195);
            txtValue.Name = "txtValue";
            txtValue.Size = new Size(100, 23);
            txtValue.TabIndex = 9;
            // 
            // button2
            // 
            button2.Location = new Point(302, 346);
            button2.Name = "button2";
            button2.Size = new Size(194, 35);
            button2.TabIndex = 10;
            button2.Text = "Read File and Display Contents";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // ID
            // 
            ID.Text = "ID";
            // 
            // Title
            // 
            Title.Text = "Title";
            Title.Width = 100;
            // 
            // Genre
            // 
            Genre.Text = "Genre";
            // 
            // Value
            // 
            Value.Text = "Value";
            // 
            // lsvOutput
            // 
            lsvOutput.Columns.AddRange(new ColumnHeader[] { ID, Title, Genre, Value });
            lsvOutput.Location = new Point(458, 79);
            lsvOutput.Name = "lsvOutput";
            lsvOutput.Size = new Size(532, 168);
            lsvOutput.TabIndex = 11;
            lsvOutput.UseCompatibleStateImageBehavior = false;
            lsvOutput.View = View.Details;
            lsvOutput.SelectedIndexChanged += lsvOutput_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1058, 450);
            Controls.Add(lsvOutput);
            Controls.Add(button2);
            Controls.Add(txtValue);
            Controls.Add(txtGenre);
            Controls.Add(txtTitle);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtTitle;
        private TextBox txtGenre;
        private TextBox txtValue;
        private Button button2;
        private ColumnHeader ID;
        private ColumnHeader Title;
        private ColumnHeader Genre;
        private ColumnHeader Value;
        private ListView lsvOutput;
    }
}